package com.example.chris.changiappv3;

/**
 * Created by chris on 25/11/2017.
 */

public class DataLocation {

//    public String fishImage;
//    public String fishName;
//    public String catName;
//    public String sizeName;
//    public int price;

    public String loationImage;
    public String loationName;
    public String catName;
    public String ratings;
    public int price;
}